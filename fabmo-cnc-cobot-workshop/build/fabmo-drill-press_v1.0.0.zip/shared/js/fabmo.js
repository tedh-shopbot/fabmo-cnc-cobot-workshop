   fabmo-cnc-cobot-workshop
   ├── drillpress-app
   ├── ripsaw-app
   ├── chopsaw-app
   ├── shared
   ├── README.md
   └── package.json